# import torch
# from torch.autograd import Variable
# ##单位矩阵来模拟输入
# input=torch.ones(1,1,5,5)
# input=Variable(input)
# # print(input)
# # print(22222222)
# x=torch.nn.Conv2d(in_channels=1,out_channels=3,kernel_size=3,groups=1)
# out=x(input)
# print(out)
# print(1111111111)
# print(list(x.parameters()))

import torch
from torch.autograd import Variable

x = Variable(torch.ones(2, 2), requires_grad=True)
# print((x+2)*(x+2)*3)
y = (x+2) * (x+2) * 3
out = y.mean()
print(y, out)
out.backward() #out.backward(torch.Tensor([1.0]))
print(x.grad)

# simple gradient
# a = Variable(torch.FloatTensor([2, 3]), requires_grad=True)
# b = a + 3
# c = b * b * 3
# out = c.mean()
# out.backward()
# # print(\'*\'*10)
# # print(\'=====simple gradient======\')
# # print(\'input\')
# print(a.data)
# # print(\'compute result is\')
# print(out.data)
# # print(\'input gradients are\')
# print(a.grad.data)